/* =====================================================
   MUSIC PLAYER
   To add your own songs: put the mp3 files in the "songs"
   folder and add a line to the TRACKS list below.
   ===================================================== */
const TRACKS = [
  { title: 'Midnight Drive', artist: 'Nova Lane',    src: 'songs/midnight-drive.mp3', a: '#7c5cff', b: '#ff5c9d' },
  { title: 'Golden Hour',    artist: 'Sunny Mirage', src: 'songs/golden-hour.mp3',    a: '#ff9f43', b: '#ff5c7a' },
  { title: 'Deep Focus',     artist: 'Quiet Atlas',  src: 'songs/deep-focus.mp3',     a: '#2dd4bf', b: '#3b82f6' },
  { title: 'Rain on Glass',  artist: 'Luna Static',  src: 'songs/rain-on-glass.mp3',  a: '#60a5fa', b: '#a78bfa' }
];

const $ = id => document.getElementById(id);
const audio = $('audio'), app = $('app'), root = document.documentElement;
const seek = $('seek'), vol = $('vol');

let index = 0;
let shuffle = false;
let repeat = 'off';            // 'off' | 'all' | 'one'
let seeking = false;           // true while the user drags the progress bar

/* ---------- helpers ---------- */
function fmt(s){
  if(!isFinite(s) || s < 0) return '0:00';
  return Math.floor(s / 60) + ':' + String(Math.floor(s % 60)).padStart(2, '0');
}
const esc = t => String(t).replace(/[&<>"']/g, m => ({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'}[m]));
const setStatus = msg => { $('status').textContent = msg || ''; };

/* ---------- load a song ---------- */
function load(i, autoplay = false){
  index = (i + TRACKS.length) % TRACKS.length;
  const t = TRACKS[index];
  audio.src = t.src;
  $('title').textContent = t.title;
  $('artist').textContent = t.artist;
  $('cur').textContent = '0:00';
  $('dur').textContent = t.duration ? fmt(t.duration) : '0:00';
  seek.value = 0; root.style.setProperty('--p', '0%');
  root.style.setProperty('--c1', t.a);
  root.style.setProperty('--c2', t.b);
  document.title = t.title + ' - ' + t.artist;
  setStatus('');
  markActive();
  updateMediaSession();
  if(autoplay) play();
}

function play(){
  const p = audio.play();
  if(p) p.catch(err => {
    if(err.name === 'AbortError') return;
    if(err.name === 'NotAllowedError') return setStatus('Browser blocked playback. Press Play again');
    setStatus('Song file not found. Keep the "songs" folder next to index.html');
  });
}
const pause = () => audio.pause();
const toggle = () => (audio.paused ? play() : pause());

function next(){
  if(shuffle && TRACKS.length > 1){
    let r; do{ r = Math.floor(Math.random() * TRACKS.length); }while(r === index);
    return load(r, true);
  }
  load(index + 1, true);
}
function prev(){
  if(audio.currentTime > 3) { audio.currentTime = 0; return; }   // restart if song already started
  load(index - 1, true);
}

/* ---------- audio events ---------- */
audio.addEventListener('play',  () => { app.classList.add('playing');    $('play').setAttribute('aria-label', 'Pause'); });
audio.addEventListener('pause', () => { app.classList.remove('playing'); $('play').setAttribute('aria-label', 'Play'); });

audio.addEventListener('loadedmetadata', () => {
  TRACKS[index].duration = audio.duration;
  $('dur').textContent = fmt(audio.duration);
  drawTimes();
});

audio.addEventListener('timeupdate', () => {
  $('cur').textContent = fmt(audio.currentTime);
  if(!seeking && audio.duration){
    const pct = audio.currentTime / audio.duration * 1000;
    seek.value = pct;
    root.style.setProperty('--p', pct / 10 + '%');
  }
});

/* Song finished: repeat one / autoplay next / stop */
audio.addEventListener('ended', () => {
  if(repeat === 'one'){ audio.currentTime = 0; return play(); }
  const last = index === TRACKS.length - 1;
  if($('autoplay').checked && (!last || repeat === 'all' || shuffle)) return next();
  load(last ? 0 : index + 1, false);                 // autoplay off: get next song ready, do not play
});

audio.addEventListener('error', () => {
  setStatus('File not found: ' + TRACKS[index].src);
  app.classList.remove('playing');
});

/* ---------- progress bar ---------- */
seek.addEventListener('input', () => {
  seeking = true;
  root.style.setProperty('--p', seek.value / 10 + '%');
  if(audio.duration) $('cur').textContent = fmt(seek.value / 1000 * audio.duration);
});
seek.addEventListener('change', () => {
  if(audio.duration) audio.currentTime = seek.value / 1000 * audio.duration;
  seeking = false;
});

/* ---------- volume ---------- */
function setVolume(v){
  v = Math.min(100, Math.max(0, v));
  audio.volume = v / 100;
  vol.value = v;
  root.style.setProperty('--v', v + '%');
  if(v > 0) audio.muted = false;
  drawVolumeIcon();
  try{ localStorage.setItem('mp-volume', v); }catch(e){}
}
function drawVolumeIcon(){
  const level = (audio.muted || audio.volume === 0) ? 0 : audio.volume < .5 ? 1 : 2;
  $('mute').dataset.level = level;
}
vol.addEventListener('input', () => setVolume(+vol.value));
$('mute').addEventListener('click', () => {
  audio.muted = !audio.muted;
  if(!audio.muted && audio.volume === 0) setVolume(50);
  drawVolumeIcon();
});

/* ---------- buttons ---------- */
$('play').onclick = toggle;
$('next').onclick = next;
$('prev').onclick = prev;
$('shuffle').onclick = () => {
  shuffle = !shuffle;
  $('shuffle').classList.toggle('on', shuffle);
  $('shuffle').title = 'Shuffle: ' + (shuffle ? 'on' : 'off');
};
$('repeat').onclick = () => {
  repeat = { off: 'all', all: 'one', one: 'off' }[repeat];
  $('repeat').classList.toggle('on', repeat !== 'off');
  $('repeat').classList.toggle('one', repeat === 'one');
  $('repeat').title = 'Repeat: ' + repeat;
};

/* ---------- playlist ---------- */
function drawPlaylist(){
  $('plist').innerHTML = TRACKS.map((t, i) => `
    <li data-i="${i}" tabindex="0" aria-label="Play ${esc(t.title)}">
      <div class="thumb" style="--a:${t.a};--b:${t.b}">
        <span class="n">${i + 1}</span>
        <span class="mini"><i></i><i></i><i></i></span>
      </div>
      <div class="info"><b>${esc(t.title)}</b><span>${esc(t.artist)}</span></div>
      <time>${t.duration ? fmt(t.duration) : '--:--'}</time>
    </li>`).join('');
  $('count').textContent = TRACKS.length + (TRACKS.length === 1 ? ' song' : ' songs');
  markActive();
}
function markActive(){
  document.querySelectorAll('#plist li').forEach((li, i) => li.classList.toggle('active', i === index));
}
function drawTimes(){
  document.querySelectorAll('#plist li time').forEach((el, i) => {
    el.textContent = TRACKS[i].duration ? fmt(TRACKS[i].duration) : '--:--';
  });
}
$('plist').addEventListener('click', e => {
  const li = e.target.closest('li[data-i]');
  if(!li) return;
  const i = +li.dataset.i;
  if(i === index) toggle(); else load(i, true);
});
$('plist').addEventListener('keydown', e => {
  if(e.key === 'Enter'){ const li = e.target.closest('li[data-i]'); if(li){ e.preventDefault(); load(+li.dataset.i, true); } }
});

/* Read every song's length in the background so the playlist can show it */
function preloadDurations(from = 0){
  TRACKS.slice(from).forEach(t => {
    if(t.duration) return;
    const a = new Audio();
    a.preload = 'metadata';
    a.onloadedmetadata = () => { t.duration = a.duration; drawTimes(); };
    a.src = t.src;
  });
}

/* ---------- add your own songs (kept until the page is refreshed) ---------- */
$('addBtn').onclick = () => $('fileInput').click();
$('fileInput').onchange = e => {
  const files = [...e.target.files].filter(f => f.type.startsWith('audio/'));
  e.target.value = '';
  if(!files.length) return;
  const first = TRACKS.length;
  files.forEach(f => {
    const h = Math.floor(Math.random() * 360);
    TRACKS.push({
      title: f.name.replace(/\.[^.]+$/, ''), artist: 'My music',
      src: URL.createObjectURL(f),
      a: `hsl(${h} 80% 62%)`, b: `hsl(${(h + 50) % 360} 85% 60%)`
    });
  });
  drawPlaylist();
  preloadDurations(first);
  load(first, true);
};

/* ---------- keyboard shortcuts ---------- */
document.addEventListener('keydown', e => {
  if(e.ctrlKey || e.metaKey || e.altKey) return;
  const k = e.key.toLowerCase();
  const actions = {
    ' ': toggle, 'n': next, 'p': prev, 'm': () => $('mute').click(), 's': () => $('shuffle').click(),
    'arrowright': () => { audio.currentTime = Math.min(audio.duration || 0, audio.currentTime + 5); },
    'arrowleft':  () => { audio.currentTime = Math.max(0, audio.currentTime - 5); },
    'arrowup':    () => setVolume(Math.round(audio.volume * 100) + 5),
    'arrowdown':  () => setVolume(Math.round(audio.volume * 100) - 5)
  };
  if(!actions[k]) return;
  e.preventDefault();
  actions[k]();
});

/* ---------- media keys / lock screen controls ---------- */
function updateMediaSession(){
  if(!('mediaSession' in navigator)) return;
  const t = TRACKS[index];
  navigator.mediaSession.metadata = new MediaMetadata({ title: t.title, artist: t.artist });
}
if('mediaSession' in navigator){
  navigator.mediaSession.setActionHandler('play', play);
  navigator.mediaSession.setActionHandler('pause', pause);
  navigator.mediaSession.setActionHandler('nexttrack', next);
  navigator.mediaSession.setActionHandler('previoustrack', prev);
}

/* ---------- start ---------- */
let savedVol = 80;
try{ savedVol = +localStorage.getItem('mp-volume'); if(isNaN(savedVol) || localStorage.getItem('mp-volume') === null) savedVol = 80; }catch(e){}
setVolume(savedVol);
drawPlaylist();
load(0, false);             // browsers block sound until the user clicks, so we wait for Play
preloadDurations();